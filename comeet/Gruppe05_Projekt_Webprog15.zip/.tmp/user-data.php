<?php

/*
 * Nur Session vars zurückgeben
 *
 * */

session_start();
echo $_SESSION["userdata"];

?>

