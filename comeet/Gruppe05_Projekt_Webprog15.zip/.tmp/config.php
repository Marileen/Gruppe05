<?php
error_reporting(E_ALL);
 
define ( 'MYSQL_HOST',      'mysql5.service' );
define ( 'MYSQL_BENUTZER',  'HTO01FLQZCHT_2' );
define ( 'MYSQL_KENNWORT',  'tj311z26' );
define ( 'MYSQL_DATENBANK', 'HTO01FLQZCHT_2' );
?>